package com.example.vmdestroyer

import android.content.ComponentName
import android.content.Context
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class StopTileService : TileService() {
    override fun onClick() {
        super.onClick()
        setStopped(this, true)
        qsTile?.apply {
            state = Tile.STATE_INACTIVE
            label = "Simulación detenida"
            updateTile()
        }
    }

    companion object {
        private const val PREFS = "vm_destroyer_settings"
        private const val KEY_STOPPED = "stopped"

        fun setStopped(context: Context, value: Boolean) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_STOPPED, value).apply()
        }

        fun isStopped(context: Context): Boolean =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_STOPPED, false)
    }
}
