package com.example.vmdestroyer

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.random.Random

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var count: TextView
    private lateinit var buttonList: LinearLayout
    private var running = false
    private var totalButtons = 0
    private var pressedButtons = 0
    private val messages = listOf(
        "[CRITICAL] Android system corruption detected (SIMULATED)",
        "[WARNING] Virtual machine instability simulated",
        "[ERROR] Recovery service unavailable (fictional)",
        "[ALERT] Visual glitch sequence active",
        "[SYSTEM] No real files are being changed"
    )

    private val spawnTask = object : Runnable {
        override fun run() {
            if (!running) return
            repeat(5) { addChallengeButton() }
            updateCounter()
            status.text = "!! MÁS ERRORES DETECTADOS !!"
            status.setTextColor(Color.RED)
            handler.postDelayed(this, 25_000L)
        }
    }

    private val glitchTask = object : Runnable {
        override fun run() {
            if (!running) return
            status.text = messages[Random.nextInt(messages.size)]
            status.setTextColor(if (Random.nextBoolean()) Color.RED else Color.rgb(255, 90, 90))
            root.alpha = if (Random.nextInt(5) == 0) 0.78f else 1f
            handler.postDelayed(this, 700L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility =
            (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
             View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(Color.rgb(8, 5, 9))
        }

        val title = TextView(this).apply {
            text = "☠ VM DESTROYER"
            textSize = 27f
            setTextColor(Color.RED)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "BUTTON OVERLOAD // SIMULADOR"
            textSize = 16f
            setTextColor(Color.RED)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 8)
        }
        count = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, 4, 0, 10)
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Color.rgb(20, 8, 13))
        }
        buttonList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
        }
        scroll.addView(buttonList)

        val start = Button(this).apply {
            text = "INICIAR DESAFÍO"
            setOnClickListener { startChallenge() }
        }
        val exit = Button(this).apply {
            text = "SALIR DE LA SIMULACIÓN"
            setOnClickListener { finishChallenge(false) }
        }
        val hint = TextView(this).apply {
            text = "Desafío: pulsa todos los botones. Aparecen exactamente 5 botones nuevos cada 25 segundos. Puedes salir cuando quieras con SALIR."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(4, 8, 4, 8)
        }
        val disclaimer = TextView(this).apply {
            text = "SIMULACIÓN VISUAL: no infecta ni modifica Android."
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.GRAY)
        }

        root.addView(title)
        root.addView(status)
        root.addView(count)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(start)
        root.addView(exit)
        root.addView(hint)
        root.addView(disclaimer)
        setContentView(root)
        updateCounter()
    }

    private fun startChallenge() {
        running = true
        totalButtons = 0
        pressedButtons = 0
        buttonList.removeAllViews()
        repeat(105) { addChallengeButton() }
        updateCounter()
        status.text = "SYSTEM CORRUPTION // SIMULATED"
        handler.removeCallbacks(spawnTask)
        handler.removeCallbacks(glitchTask)
        handler.postDelayed(spawnTask, 25_000L)
        handler.post(glitchTask)
    }

    private fun addChallengeButton() {
        if (!running) return
        totalButtons++
        val number = totalButtons
        val b = Button(this).apply {
            text = "FIX ERROR #$number"
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(115, 15, 25))
            setOnClickListener {
                if (!running || !isEnabled) return@setOnClickListener
                isEnabled = false
                text = "✓ FIXED #$number"
                setTextColor(Color.GREEN)
                pressedButtons++
                updateCounter()
                if (pressedButtons == totalButtons) finishChallenge(true)
            }
        }
        buttonList.addView(b, LinearLayout.LayoutParams(-1, -2))
    }

    private fun updateCounter() {
        if (::count.isInitialized) {
            count.text = "PULSADOS: $pressedButtons / $totalButtons   |   PENDIENTES: ${totalButtons - pressedButtons}"
        }
    }

    private fun finishChallenge(completed: Boolean) {
        running = false
        handler.removeCallbacks(spawnTask)
        handler.removeCallbacks(glitchTask)
        root.alpha = 1f
        status.text = if (completed) "¡SIMULACIÓN COMPLETADA!" else "SIMULACIÓN DETENIDA"
        status.setTextColor(Color.GREEN)
        val result = TextView(this).apply {
            text = if (completed) "Todos los botones fueron pulsados. Android está intacto." else "Saliste de forma segura. Android está intacto."
            setTextColor(Color.GREEN)
            gravity = Gravity.CENTER
            textSize = 14f
        }
        root.addView(result)
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(spawnTask)
        handler.removeCallbacks(glitchTask)
        super.onDestroy()
    }
}
