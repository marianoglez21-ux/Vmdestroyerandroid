# VM DESTROYER — Button Challenge

Simulador visual de terror para Android 12+ / Virtual Master.

## Desafío
- Al iniciar aparecen 105 botones.
- Cada 25 segundos exactos aparecen 5 botones adicionales.
- Cada botón se puede pulsar una sola vez.
- La simulación termina cuando todos los botones existentes han sido pulsados.
- Incluye un botón visible **SALIR DE LA SIMULACIÓN** para cerrar el susto en cualquier momento.

## Seguridad
No infecta Android, no modifica ni elimina archivos, no bloquea el dispositivo y no se ejecuta en segundo plano. El usuario siempre puede salir.

## Generar APK en GitHub
1. Sube todos los archivos de este proyecto a un repositorio GitHub.
2. Abre **Actions** y ejecuta **Build Android APK**.
3. Descarga el artefacto `VM-Destroyer-debug-apk` de la ejecución terminada.
4. Extrae e instala el APK dentro de Virtual Master.

El mosaico opcional de Ajustes rápidos **Detener simulación** de la versión anterior sigue incluido en el proyecto.
